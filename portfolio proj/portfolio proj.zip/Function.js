var i = 0;
var h = 0;
var y = 0;

const error_pop_up = document.getElementById('Wrapper');

function visible() {
  error_pop_up.style.visibility = "visible";
}

window.onload = function() {
  
  function openFullscreen() {
      if(elem.requestFullscreen) {
        elem.requestFullscreen();
      } else if
      (elem.webkitRequestFullscreen) {
        elem.webkitRequestFullscreen();
      } else if (elem.msRequestFullscreen) {
        elem.msRequestFullscreen();
      }
    }
  openFullscreen();
}

function change() {
    const things = ['P̸̖̙̃̂́̾̊̑̌o̷͓̺̦̺̳̺̅̍͂̐̐r̵̟͉͇̿̀̿͘ṭ̵̨̡͇̻̤͖̫͇̭̈́̔̐́͠f̴̧̛̩̝̽̇͆͒͗͌͂́͗̄͝o̵̰͍̳̖̬̭̦͍̘̮͊̐̒͐͐̂̄̈́̔̀̑̆̕͠ͅl̴̨̧̡͉̺̳̰͖͚̫̫̥̈́̂͘͝͝i̶̡̨͎̝̻͎͍͎̳̩̊̓̈́̉̈́͆̓͝͝ͅṏ̶͕̹́̚', 'P̶̳̝̪͇̠̼̹̞̬̫͜͠ơ̷̡̹̼̞̰͙͆͂̀͋͗͛̉̓̃͒́̕͝͠ř̶͖͓͚̜̞̥͍͖̐̋t̷̞̾́̿̊̊̂̌͂̀̀̃̀̔̚f̶̢̢̼͕̠͇̪̤̎̂̆̏̇̽̽̏o̷̡̨͍̳̼͍͕̳̫͓̖͕̦̪̞̲͠l̷̘̗͚͉̩͙̬̙̯̤͈̓̓̓̎̆̕í̸̖͔̰̳̩̤̣̦̯̃͌͋̇̈́̂̉͆̋͝ǫ̴̨̞͈̟̦̯̜̣̥͙̥͐͆͆̍͐̐̓̃̑͘', 'P̵̧̜̣̬̝̲̖̼͙̠̭̣͛̓ͅo̵̺̦̲̗̻̣̯̍ř̵̲͓͇͎͓̻͙̕t̶̛̬̹̜̟̱̠̻͝f̴͍͗̃̈́̀̂̆̈́̕͠͠ŏ̶͓͍̲͍̯͎̥͝l̴̛͍̣̻̙͈͉̳̹͔̬̣̦̫̿̅͋̄̇͛͑̊́͘͜͝i̵̧̫̲͕̳͓͎̺͖̠̪̼͔͉͕͊̇̋̈o̸͎̟̲͈̘̭̜̮̺̽́̐̀͋̕̚', 'P̸̢̦̺͍̮̮̹̯̳̘͕̣̖͈͋̾o̸͕̻̙̭̼̰̮͕͗̅͛̑̀̎̇̌̃r̶͙̲̠̓t̷̻̜̙͎͓̾̂̔͋̇̽̅̌͒̌̽̌͗̐̚͝͝f̴̢̡̫̜̦̹̞̥̲͈̥͖̰͍̘͔͗̉̅͠͝ò̴̢̜̺̰̪͍̣̯̻̺̩̰̣̻̱͈̑͐l̵͖̉͂i̷̡̢̨͖̰̲͍͖̟̯̞̝̭͒̇͊̉̚ǫ̸̺͔̮̪̼͌͛̅̊̆̃̃͂͝'];
    var thing = things[Math.floor(Math.random()*things.length)];
    var name = document.getElementById("WPNAME");
    name.innerHTML = thing;
    const array = [];
    const original = document.getElementById('windows_pop_up');
    let i_am_horny = original.cloneNode(true);// "deep" clone
    const horny = i_am_horny.id = 'windows_pop_up' + ++i;
    let i_am_replica = i_am_horny.cloneNode(true);
    const replica = i_am_replica = 'replica_pop_up' + ++h;
    array.push(i_am_horny.id);
    var randpos1 = Math.random() * screen.height;
    var randpos2 = Math.random() * screen.width;
    document.getElementById('Wrapper').style.top = randpos1 + 'px';
    document.getElementById('Wrapper').style.left = randpos2 + 'px'; 
    // or clone.id = ""; if the divs don't need an ID
    original.parentNode.appendChild(i_am_horny);
  }

function load_BSOD() {
    clearInterval(change);
    process();
}

function swapper() {
  if (y <= 15) {
      change();
      y = y + 1;
  }
  else {
      window.location.href = "./H̷̳͎͖̃͆̈́͑̇̌́a̷̫̬̻͗̓̀c̶̡̫̭̣̦̼̼̤̜̄̐̌̅̓̈́̓͊͆̂̒̓̔͠k̴̛̳̈́̈́̽̽̆́͗͑̄̔͛͝í̵̹̼̠̙̥̬̗̖̬͔̫̯̀̓̓͆͛̃͗͛͘̕͘͠ͅń̷̨̻̲͈͖̣͓̣͆̈́̅̿̈́̕g̷̯̰͓̥͈̳̦͕͗̎̋̋̅͆̅̐͘̕p̴̺̖̠̗̪̹͓̯̘̈̿͗̓͛͑̇̀̑͛̂̚͘t̶̢̢̡̹̹̖̞̗̭̠̝̼̘͔̩͌͋͂2̶͚͚͕̫̹̯̼͇́̌̆̐̅̊̋̈̎̕.html";
  }
}

function changeloc() {
  window.location.href = "./Hacking_Portfolio.html";
}

function change2() {
  const things = ['P̸̖̙̃̂́̾̊̑̌o̷͓̺̦̺̳̺̅̍͂̐̐r̵̟͉͇̿̀̿͘ṭ̵̨̡͇̻̤͖̫͇̭̈́̔̐́͠f̴̧̛̩̝̽̇͆͒͗͌͂́͗̄͝o̵̰͍̳̖̬̭̦͍̘̮͊̐̒͐͐̂̄̈́̔̀̑̆̕͠ͅl̴̨̧̡͉̺̳̰͖͚̫̫̥̈́̂͘͝͝i̶̡̨͎̝̻͎͍͎̳̩̊̓̈́̉̈́͆̓͝͝ͅṏ̶͕̹́̚', 'P̶̳̝̪͇̠̼̹̞̬̫͜͠ơ̷̡̹̼̞̰͙͆͂̀͋͗͛̉̓̃͒́̕͝͠ř̶͖͓͚̜̞̥͍͖̐̋t̷̞̾́̿̊̊̂̌͂̀̀̃̀̔̚f̶̢̢̼͕̠͇̪̤̎̂̆̏̇̽̽̏o̷̡̨͍̳̼͍͕̳̫͓̖͕̦̪̞̲͠l̷̘̗͚͉̩͙̬̙̯̤͈̓̓̓̎̆̕í̸̖͔̰̳̩̤̣̦̯̃͌͋̇̈́̂̉͆̋͝ǫ̴̨̞͈̟̦̯̜̣̥͙̥͐͆͆̍͐̐̓̃̑͘', 'P̵̧̜̣̬̝̲̖̼͙̠̭̣͛̓ͅo̵̺̦̲̗̻̣̯̍ř̵̲͓͇͎͓̻͙̕t̶̛̬̹̜̟̱̠̻͝f̴͍͗̃̈́̀̂̆̈́̕͠͠ŏ̶͓͍̲͍̯͎̥͝l̴̛͍̣̻̙͈͉̳̹͔̬̣̦̫̿̅͋̄̇͛͑̊́͘͜͝i̵̧̫̲͕̳͓͎̺͖̠̪̼͔͉͕͊̇̋̈o̸͎̟̲͈̘̭̜̮̺̽́̐̀͋̕̚', 'P̸̢̦̺͍̮̮̹̯̳̘͕̣̖͈͋̾o̸͕̻̙̭̼̰̮͕͗̅͛̑̀̎̇̌̃r̶͙̲̠̓t̷̻̜̙͎͓̾̂̔͋̇̽̅̌͒̌̽̌͗̐̚͝͝f̴̢̡̫̜̦̹̞̥̲͈̥͖̰͍̘͔͗̉̅͠͝ò̴̢̜̺̰̪͍̣̯̻̺̩̰̣̻̱͈̑͐l̵͖̉͂i̷̡̢̨͖̰̲͍͖̟̯̞̝̭͒̇͊̉̚ǫ̸̺͔̮̪̼͌͛̅̊̆̃̃͂͝'];
    var thing = things[Math.floor(Math.random()*things.length)];
    var name = document.getElementById("WPNAME");
    name.innerHTML = thing;
}

function Fullscreen()
{
  if (elem.requestFullscreen) {
    elem.requestFullscreen();
  } else if (elem.webkitRequestFullscreen) { /* Safari */
    elem.webkitRequestFullscreen();
  } else if (elem.msRequestFullscreen) { /* IE11 */
    elem.msRequestFullscreen();
  }
}

function Fade() {
        var counter = 0;
        var arr = [];
        var E1 = document.getElementById('error1');
        var E2 = document.getElementById('error2');
        while (counter != 2){
        var E3 = Math.random() * 21;
        arr.push(E3);
        counter++;
        }
        E1.style.opacity = arr[0];
        E2.style.opacity = arr[1];
        arr = [];
}

function Fade2() {
    var E1 = document.getElementById('error1');
    var E2 = document.getElementById('error2');
    var E3 = Math.random() * 21;
    var E4 = Math.random() * 21;
    E1.style.opacity = E3;
    E2.style.opacity = E4;
}

var percentageElement = document.getElementById("percentage");
var IssueElement1 = document.getElementById("issueText");
var IssueElement2 = document.getElementById("issueText2");
var IssueElement3 = document.getElementById("issueText3");
var IssueElement4 = document.getElementById("issueText4");
var IssueElement5 = document.getElementById("issueText5");
var IssueFace = document.getElementById("face");
var body = document.getElementById('body2');
var QRImage = document.getElementById('image');
var QRCODE = document.getElementById('QRCODE');
var percentage = 0;


const things = ['5̵̮͚͓͖̼̋͌̈́̄̓̀̂͋͛͆̅̏̍̄̽̄̑̓̒̾̍̏̇͂̈́̋̏̕̚͠͠͝1̶̧͚̞̗͍̺͛̓̈́̇́̾͂͗̀͐̅̒͆͑̊̽̆̈́̅͘͠͠ͅ',' ̵̢̼̟͕̗̝͉̟͙͚̙͚̯͖̼̱̤̟̓̐̓͛̌́̀̈́͂͋̾̉̏̏̉͂̑̎̂̀̔̓̃̚̕͘͜͝5̴̡̧̝̤̖̥̥̳̜̤̲̟͇͈̖͕̬͇͓̱̖͍̬̟̟̘̩͕̐̈́̽͗̊͗͂͗͋̑̄̏͋̋̒͝ͅ3̸̢̨̛̬̙̫͚̤͓̩̬͙͇͇͂̀̐͋͒̈̈́́̆͊͒̂͂̄̅͐̎͘̚͝͠͠ ̴̡̡̧͇̙̟̞̠͎̝͔͉̱̖́̾͑̌̀̐͐̈́͒̒̉̽̊́̔͛̌̈̂̓̒̚͜͝͝͠ͅ', '5̵̡̰̮̺͇̬͇̲̻̞̼̹̲͕̖̣̲̰̔͜4̶̡̢̨̨̫͕̲̼̬̪̺̮͇͈̬̥̲̳̮̻̬̹̬̝̻̪̺̝͖̩̟͇̓̃̒̐̆͜ͅ', ' ̴̢̧̛̲̗̼̫͖̅͆̓̄̒͐̓̄̅̄͑̾̓̄̍̊͑͐̅̈́̎̊̚̚̚͜͝͠6̴̯͕̦̤̬̣̣̋̈́̍̽̊͗́͋́͑̓͆̓̅̈͊̿́̇̽͊͆̈́͆̉̽͘̚̕͜͠͠͝͝5̴̢̢̢̡̡̨̢̥͉̻͙̤̣̙̣̬̺̰̮̙͚̥͙̰͇̠̟̘̼̠̋̏́̋͑̋͒̚͜͝ ̷̡͓̠̤̮̟͉̙̫̜͍̺͚̯͖͉̗̗̝̂̅͋̔͌̓̌̌̇͝͝ͅͅ,', '7̴̛̌͑̈́̈̏͐͛̈́̐̓̊̀̋̊͌̕8̵̧̧̱̖͕̪̘͈̱̠̟̳̰̼̖̹̩̥̙̬͈̰̹̟͍̲͙̙͗̐͛̉͝ͅ ̴̥͕̳͕̥̓͂́͆̐̍͛̌̀͌̀̉͠͝', '4̸̧̠̦͕̟̠̥̱̫̗͇͉̞̲̮̭̫͚͙̬͗̔̔͊̍̇͆̒̎͐́̋̋̽̉̒̅̿͂̕ͅͅ3̶̢̧̤̥͙̭͉͍̣̱̻͇͉̑̃̋̽̀͂̐̀͜͜', ' ̵̧̛̛͈̪̲̪̒̏͛͊͑́̊̌̽̀̋͂̓̓̐͑̍́̈́͗̃̕̚ͅ6̷̙̜̪̜̯̭̒̈́̈͑̃͂͂̀̾̇̀͊͒͌̾͋̀͋̉͊̃͐̐̚͝7̶̧̢̮̝̪̗̮̥̦͖͙̠̗͈͓̰̋͋͒̅͒̈́͆́̉͌̏͒̿̾̌̓̍͊̒̋̐̋͝', ' ̶̡̛͓̪̫̭̘̣̜̗̂̑͂̽̇̄͋͑̀̆͑̌̀̇̃̂̒͌̌̋̄̈̅͘̚͘̚̕͝͠͠6̴̧̧̡̛̛̗͖͖͕̮̠̘͙̬̙̠̤̥̣͉̦̖̮̞͓̪̖̰̫̰͎̠̩͕̬͒̿̇͗͑̽͋̓̊̏̈̅͗̌̊̀̊͠ͅͅ9̴̢̧̢̨̡͔̼̱͎̗̙̼̣̗̩̞̺̙̥̜̤̳̬͈̖̺̜̬̩̦̪͛̉̂̃̎͛͗̐̆͜͜', ' ̶̨̨̳̮̝̠̖̬͕̬̜̝̭̣͈̦̮̟̯̙̹̏̍͑͑̀̆́̎͑̾́4̴̢̨̙̜̦̜̺͖̪̪̼͍̳͎̩̙̰̟̙͖̻͕͔͙̝̔̽̈̍͒̇͑́͜ͅ9̴̨̢̺͚̻͔̟͍̪̝̖̜̭͇͍̿͂̈̏̄͛̅̒͐̽͂̒̌̏͊͆̑̎͛́͋̓͘͘', ' ̴̡̯͖̣̫̞̘̺̘̟̭̩̈̉̈́̆́͝8̵̛͚͕̪̮̉̄̆̾̅͊̋̇̇̉͋͊̾̊̓͝͝͝8̶̢̧̛̫̜̙̎̈̈́̎̈́͌̔͛͋̊͑̀̀̓̽̀̈́̍̿̚̚͝ ̸̧̢̧̲̤̥̞͕̰͉̩̮̲̙̦̥̻̹̱͓̺̻̹̓̀̌̒̏́͋̎͊͆̀͌̈́̅̅̏̏̈́͘̚͜͝ͅ', '8̵̨̡̘̲͖͍̳̦͙̜̙̺̩̤͉͎̩͚̘̝͙̟̦̣̜̞͇͈̥̬̹̹͕͓́̋ͅ4̶̨̢̨̢̳͖͉͚͔̼̲̼̫̼̥̲͖͓̖͖̩̹̤̮̳̾̐̓́͆͌͊͗́̈́͒̎̏̋̓̈́̀̃͝͝͝ ̶̧̢͙̜͓̭̥̪̙͍̰̘̙͙̝̟̺͇͇͉͔̮̌̓̄̄͋̒̀̈́̏̄̄̌̔́̇͊́͠ͅ', '9̵̡̨̢̛͙̠̭̤͖̤͖̗̟̖͇̭̻͕͉̠̤̭̮̘̪̣͇͔͚͒̄́̾̐̅́͗̏̀̂͗͒̈́͐̀͂͘̕̚4̸̨̛̟̣͕͚͇̞͕̲͚̗̳͖͎̜̮̈́̍̈́̂͂̔͒͌̂̓̀̔̂́̏̌̉̆̋͗́̊̎͘̚͜͜͝͝ͅ]'];
const issue = ['y̵̫͔̔̔̽͋̃̓͗̈̓̆̇̐͋͆͆̕ơ̵̛͇̯̣̞͑͗̈̋̅̂̃̽̑͊́̾͗͒̈́̏̀̋͂͛͆͋̑̔̆̇͘̕͘͠ͅͅų̸̧̨̧͈̰̘̮̯̠͍̦̣̻͉̜̟̯̙̯̥̙̤͇̤͍̟̞͉͖̖̫̒̀̿̊̏͘͜͝ ̵̢̡̨̨͔͕͈̗̺͓̝̘̭̹̹̹͚̩̝̭̜͔̼̩̭̪̜̮͈̭̟̫̿̋̃̎͜a̷̢̳͖̞͚̮͓̩̰̪̝̝͔̣̮̱̜̘̣̜͚̮̖̐̒̒̊͆̓̌͜͝͝͠ͅͅr̴͎̰͇̹͓̘̺̝̈́̀͐̅̌̅̇̽̀̉̊̊̀̂̓̕͝ẹ̸̡̧̧̛̮̙͔̗͇͍͇̬͉͚̩͈̙̳̙̭̲̮͇̝̘̩̎͂̽̉̑͛̍̋̌̂̔̀̄̑͐̔͗͛͋̚̕͠͠ ̸̡̭̳̰̹̟͚̱̲̝̰͓̀̔̌̿̂̿̈́͊̓͊̄̔́̆̀̏̓̿͑͛̈́̕͘͝͝͝b̸̦̫̬̗͕͇̜̝̳̯̯̯́̂̿̌͌̓̏͛͂̕̚͘1̶̧̧̦̰̮̟͍̳̱͙̠̞̮̦̺͙͚̗̝̠̗͕̝̈̆͋̏̿͑͋ḭ̷̛̛̬̟̝̙̑̋̈́̀̔͒͊̃̇͐̈́̉́̇̽̍͐̕̚̚̚͝n̷̘̤̱̭̩̮͗̋̿̿͌̇̀͊̍͐̊̏̍̓͊̎̑̓̽͋ğ̵̢̢͕͇̙̱̝̠͔͓̻͎̲̼̭̥̣̿͑̽́̓̂͑̌͘͜ ̷̨̼̖͔̤̹̳̟͇̗̠̙̹̝͍͋̇͋̎͘ḩ̵̛̻̰̖̫̼̘̮͔̖͎̖̗̜̜̩̮͔͍̻̻͍͙͈̭͕̥̹̻̱͎͇̊̓̐̇͑͑̐̍̈̀̏̽̒̇̈̾͊̓̑̏̂̒̂̀̚͜͜͝͝&̷̧̜̤͇͙̺̣̰̯̻̟̦̣̗̺̲̝̼̽̾̊̈́͘͝c̴̢̡̨̢̡̡̧̪̥̣̱͕̯͙͎̣̫͉̱̹͕̰͖̮̥̻̘͍̹͓͉͖̄͆̉̇̐̐̾͗͑͐̎͊̕̚͘͜͠k̴̢̢̧̛̰̥͉̱͇̮̲̲̙̰͈͉̣̗̱̖͊̄̄̍̈́̈̆̏̃̃̇̑͐̈́͛̂̈͛̌̓͆̏̏̊̈́̂̀̚̕̕̕͜͝͝e̶̢̢̡̨̱̙̪̪̟̗̬̯̙̹̖͎̰̬̗̝̬͔̲͙͉͚̥̹̳̮̘͓̔͋̇̽̇̄͛͆͑͂͋̆͊̍̌͆͂̍̈́̌͜͜͝͠͝ͅd̵̺̲̼̣͕̣̹̣̱͚̥̓̈́̊̊́̂̽̂̀͛̈́̾͌̌̉̀͛̅̿̿̈́͝, 1̶̢̺̟̟̗̪̱͚̥͇͗̉̌̇̈́͛̅͝0̷̢̢͙̯̙̬̯̦̔̏̓̈̀̅͑̎͗͗̚0̵̢̖̭̝̲̯͕̫̰͛̽̊͆͐̔͊̇̾̓͌̕0̷̡̭͍͉̯̟̺̳̟̹̖͇̪̽̓͑̈́̓̕̚0̶̘̠̥̜̻̜͉̮̃͊̏̀̈̂͛͝1̷̠͚̘̓͗̋̔͐̄͊̀̇͝͝͠͝ͅ1̵͙̲͂͋͂̐̋̈̄͂̆̂́͑̋̎̚0̴̛̥̦̬̜͍̃͊̃̔͂́́̒̎̒͜0̵̬̬̫̇̒̀͋̓͌̂͋̈́̊̓̽̇̒̚0̷͕͔̭̝̭̰͕̰̿0̵̯̱̠̩̮̣͈̺͉̦̜̼̉̌̓͒̾̍̔͊͝͝͝0̸̭͔͇͚͎̺̭̘̭͔̤̪̞̾̄͌̇̊͗0̸̠͚͔̘̩͆̇͂̈́͌͆̌̂͘͝0̴̡̙͇̻̝͎͚̙͙̜̤̌̀̀̀̋̿̏̑̾̂̅͘̕͜͝͠͝0̶̡̲̰̦̠̺̗̮̉͋̃ͅ1̵́̚͠ :̵̤̊͌Ḏ̸̛̭̭͇͓̤̲̘͕͂͛͑̿̓͌̇̀̕͝͠ͅ:̵̡͇̰̬̞͙̮̏̀̄͂̌͊̾̈́̀̐̎̀͑̋̚D̶̺̳̗͓̟̘̥̪̤̦̹͚͓̰̆̑͌̔͌̅͊͊̐̑̈́̕͝͠:̴̡̡̨̮̗̲͓̳̼͛̂̂̀͛D̶̮̬̮͈̼͆̔͝Ď̷̡̖̺̙̲̑̒́͒D̵̢̫̙̫̣̎̈́̀̑͗͝D̴̬̥̖́͆̽D̶̛̰͓̻̙͈̪̥̪̺̤̦͉̿́̓̿̂̈́͋͒͘̕͘Ḑ̴̞͉̦͋͐̕D̶̛͉̖̱̪̠̬̥̠͆̍͂̃̔D̶̫̩̣̮̥͎͙̈̐̓̇͂ ', ];
const Issue = ['Ĉ̶͇̞͚͉̼̭͖͓̣̊̃́̓̐̀͋̌͗̌̿a̶͎̜̓̎̀̈́͊̉̈́͒̍̂̇͘͠r̵̩͈̃͗̄̋̌̀͊̿͆̇̔͗̆̎p̷̧͕̙͎͎̂́̿͊͑̃̄̈́́̓̆̓̽͘͘͜ͅę̴̭̤̫̙̻̣̩͋̈́͒̇̀͂̕͠ ̸̡̱̦͇͎̟͈̹͈̯̪͈̻̼̅̍̇̈́̀̊͠ͅd̴̛̘̝̤̪͇̥̖̎́̅͑̄̂́̄̆͂̅̊͠͠i̸̢̫̘͖̩̫͈̩̣̖̣͙͔̾̾̾̂̍̔͂̽̂ḛ̸̢̛͙̮̫̘̰̜̘̞̥̬͙̼̮̀͐̃̆͆̃̎͊͛̚m̴̧͍͎̰̼̠̠̓̓,̴͔̪̰͉̭̜͖̤͎͎͙͎͔͕̩͝ ̶̩̞̺̏̓͐̃̏̈́͑̂͐͊͘͜͝ȇ̷̪͇̣̲̪͉̜̑̈́̅̌̈́̋͂̔͘ẗ̴̡͈̫̯̳̺̗͍͇́͋̐͑̅͆̍̆̆͛̆ ̶͇̰̼̼̦͔̬̙̭̩̖͑c̸̨̡̳͉̜̝͈̘̦̳̘͍̉͝e̶̪͔̾̈͂̏͝ț̸͛̂̀̈́̈́̑̉̀̌̏͘̕͝ȩ̴̢͓̹̣̭͙̮͈̮̞̜̺̰̜͌͐̒̀̽͂̇͘r̶̡̢͉̩̣͚̰͚̻̺̀͘ą̴̗̱̣̜̼̲̪̳̹͈̓̉͗̎͆̿̃͂̀̓̌̈́̄̆͝,̴̟͔̥͖̣͎͙̲̱͓̈͜ ̸̖̫̱̹̯͖̖̣̅͐̉̊̃̈́̃͘͜c̶̝̦̯̃ų̵͙̹͎̥͖̻̱̦͓̹̝͕̓̿m̴̧̢̛̼̘̟̻̬͚̥͚̦͓̤̓͂͗͋̚̚͘͝ ̸̧̞̱͔̭̘̼͛̉̑̿̿̊̏͐̆̾̈́ͅl̴̳̟͑̍̌̐͊̈́̓ą̶̹̘̦̔̑u̸̡̦̹̜͔͈̙͎͍͗̀͌d̶̢̛̪̬̻͍̟̠̦̞̜̝̦͚̀̈́͗͆͑̾̽̓͜͜͠͠ȩ̶̨̯̙̝̗̱̳̱̯̥͓͊̇̈́̈́̔̄̀̑͠,̶̧̧͉̰̹̦͎̯̟̠̟͙͊͛̂̆̐̄̉͒̉͝ ̶̨̨̗̭̓̔̂̀̆͌̃̑͂͝͝͝ç̴̗͖̲͖̹̔u̵̧͙̝̠̪̝̟͈̹̫̜̓͋̈́͐̈͊̐̔͗͐͝͠r̵̡͈̪̰̜̱̩͇̀̾̂͜͝r̴̞̹͕̰͙̫̱̤̮̮̆̂͛̉͜͠͝i̶̛͇͎͈͚͙̖̒̍̃̑̑͂͗̈́c̶̬̗̲̲̲͚͙̼̕u̶̲̹̘͈͉̅̊̈͐̂͌̓͘͜͝ĺ̶̮̜̠̭̖̤͖͈̮̺̩̪̍̿́́̈́̾̉̓͝͠͝ư̶̮̤͎̤͆̿̾͆̑͂͑́̅̈̋̅͝ṃ̸̫̬̰͇̀̎ ̷̗͔̺͍͈̝̝̭̗̬͍̋̃̿͐͋͗͐̄͊́͝v̵͍̼͕͆̎̏͗̓͑̓͌̊̃̄̈́̈́ï̵̲̹͖͈̥͔̣̻̻̖̟̰̭̣͓̕t̸̡̖̩͇͍͔̽̒̃̀̓͋́̈́̋̓͗ạ̶̢̘̫̼̹̝͓̝̦̳̦̯̫̌̄́̇͛͗́̌̎̍͆̾ͅȩ̶̻̜͖͕̙̭̹̝͇̠͛̓̔́̋̓̍̿͜ ̴̧̢̯͈͕͍̥͍͈̜́̿̒ą̴̛̺̳̼͋̌̀̂̀̿̊͜n̵͈͉̣͎̺̟͚͓͎̹̱̒͌͋ͅd̵̛̼̩̀́͌́͐͊̑̈́͗̕̚̚͠ ̷̡̧̨̛̜͍̘̭͆̇̒̓̏̚͝m̴̢̢͕̯̦̳̠͖̥͕̂e̵̩̭̱̿̓̂̅̌̔͂̐͊̈́̉̈́͛͘͝a̶̙̗̝͚͚͔͙̭͇̲͙̲͉̰͂͗̀̒͂̈́͊̌̈͝ ̶̮͙̻̠̲̦̦͗͋̓̓͗̾̂̄͘͝c̷̗͈̏̒̈́̊̓̽̅̏̽̉͂̅͝͝ư̸͔̽̿͋͆̽͝ļ̷͔͖͉̱͚̹͓̲͗̾̇́͆̊͌̾́̓̑̔͜͜͜ͅp̴̧̡̛͓̥̪̠̱̹̪̈́̾̋͗͋̒̒̈͐͠͝ą̶̲̠̺̝̬͉̰̬̖̗̮͚̠͒'];
const issue2 = ['0̸̨̩̣͚̈́̐1̸̢̧̨̳̙͚̜͈͔̮̟̖̥̟̓̀́̉̊̚͠0̸̨̰̉̽1̷̡͎͙̰̻͕̘̲̭͒̆́̒̊̎̌̉̚͘̕͝͝0̶͙̽̾͗̄̾̃͗̎̽͋̆̎̇̑̀̈́͌1̶͓̝̖͖̻̗̰̓́̒0̴͕̈̂̚0̸̢̖͉̩̭̽͆͂̿̌̿̏͂͊͗͠͠͠0̴̭̰͉͖͔̘̊́̅̂̀̏0̷̤̓̀͊̀̀̑̋̏̈͝͝͝͝1̸̧̧͖̜̯͖̳̤̖̱͕͆̄̑̽͂́̈́̈̕͘1̸̢̛̀͑̄͂͋̓̾͗̏̀̓͌̿͋̕1̶̯̤͚̫̥̬̺̟̞̫̳͍͓̩̘̫̔̃̏͑͊͜1̵̧̟͕̤̞̱̣̹̳͈͐̂̈́̈́́̏͒̃̏̌̅͐͌͘͘͠͝1̸̳͔̱̺́̈́̍̓̓̀̍̄̉̈͗͘̕͝͝͝ͅ', 'ẍ̴̧̟͚̞̥̻̻̲̞̥͚̦̫̪̯̿̀́̌̈́̔̔̅̒͆̒̿̑̚ͅͅǒ̶̧̻̮̖̘̻͉͑̾̐̾͗͝n̵̨̛͖͕̳̜͖̲͈̜͕̙̏t̵̢̝̖̜̰̻͚͙͒̋̀́͑̈́̋̾ͅa̸̡͚͓̱̬̦̣͉̞͚̭͇̝͕̎͐͜͜ͅḃ̶̫̳͎̰̠͎͎̥̐́̒͐͋̒̐̋̐̚͘͜͠.̴̧̹̹̠́c̶̖̰̱̗̮̙͓̭͍̹͎͙̮̟͗̆̀̈́̿̒͋̋̽͛̓͑̃̈́̂̕ō̴̢̭͈̙͙̣̹̝̼̼̼̩͍̺͂͋̀̾̽͋̉̐̾͗̅͘̚ͅm̴̳̣͖̫̗̼͚̝͇̖̮̤̠̞̺̱̓̈̄̒̐̈́̑̈́̿̏̚͘͜/̷̨̨̟̤̱̠̅̉̕ͅs̷̛̪̞̭̬͎̺̓̆̈́͋̕̚̚͜͠ţ̷̛͖̬̗̩͚̬̬̗̰̪͈̼̓̉̇̇̆̀̆̽̿̃͗̿̚͝ò̷̪͖͔͔̈́̊̒̀̈̐̆́̽͆̆͆͋̄̆͘p̸̧̛͍̫̻̯̣̞̣̠͚͙̩̳̫̼͙̱̐̉̈̎̅̓̈̂c̷͚̩̽́̓͌̾͠o̸͕̐̈̔́͌̌̋̿͑̽͠d̶̡̳̤͈̘̯͆̓̓̍̓́̀́͒̚̕͘ͅë̴̢̨̮̠̟͇́̅̎̊'];
const Issue2 = ['ẍ̶̢̡͎̗̮̣̣̺̣̫̭͇̬̟͙̮͕̏͛̽͆̈́̎͊͐̌͗̉̀̔͐̕͜͜͝ǫ̷̙͕̗̳̝̻̣͙͇̯̏̀̊͝n̴̡̢̧̞̮͉̰̖͈̙̦̲͕̓̎̏̉̒́̃͘t̸̡̡̡̪̱͎̝͉͙̽̉̔͜͜͝ͅa̵̧̘̬͚̮̮̟̪̩̣̖̩͉͈͔̠͗͐̈́͒͜b̶̧̛̯̰͆̄̀̊͐̓̿̈́̋͒̈́́́͐͆̕͘͝.̷̦̲̼͓͎̗̗̫̯͎͛͛͌̅͋c̸̡̜̳̻̹͙̓͜ͅo̵̢̳̹̣͕͍̙̤͚͚̱̭̐̈́̈̔́̈́͑͠͝ṁ̶̘̖̣͕̼̅̈́̾͗̇͝ͅ/̶̢̫͚̹͓̠̱͉͔̯͕͕̦̜̈́s̵̛͕͓̫̻̟̦̈́̍̐̏̎͒̌̊̆̈́̑͠ẗ̴̡͖͎̠̰͎̱̞̼͇̟̩̥́͑̍̋̀̔̈͛̋̅̐͝ǫ̷̨͚͔̳͕̩̯͂̏̀͂́̏̒͊̈́̎̾̀͜͠͝͝p̴̧̧̢̘͖̜̦͓͕̟̱̘͕͚̟̣͚̦̖͌̀̉̌͛̈́̉̿̃̈́̐͂̓̿̿̅͘͠͝c̶̟̭̩̰̲͚̮̖̅͐͆̽͘ọ̴̼͇̤̈́̀̿̒̐͌͛̒̌̕͜͝d̵̻͉̝̙͕̻͚͙͖̦̦̠̋̈́͆̆̾͑̈́͆̌̓͑͐͌̐́̚͝e̸̢̢̨͇̰͔̝̰͙̫̞̝̜̦̗̙͔̜̅͋̕', 'xontab.com/stopcode'];
const issue3 = ['If you call a support person, give them this info:', 'IF IF IF IF IF IF IF IF IF IF IF IF IF IF IF'];
const Issue3 = ['Ȉ̴̡̻͔̼̞̳͖̩͓͔̳̮̰̼̗͂͐͋́̔̇̀͊̀̆͊̇̀̈̆͘͠ͅF̸͔̪̀̑̀̾̑̃́̿̄͂͛̉̈́̉͐͗̓͆ ̴̢͖̩̓̒̂͊̾́͌̾̋̇̊́̐͛̇̕͝͝Ǐ̷͇̫̫̱̈́̀F̸͇̮̮̥̫̪̈́͌̾̉̀̄͗̀͊̓̒̃̑ ̷̧͈͍̗͔̰̠̮̟̅͐͌͋̔̄̈́̅I̴̢̧̪̹͕̮̜̣̣̣̘̘̜͋́̓̏͋͂̓̑̄̀͛̉̕̕͜F̷̛̥̞̣͈̙̩̯͙͖̳͇͔̀̎͗͑̒͆̃̉̉͐́͛͝͝ ̵̯̟͒͐I̸̺̳̙̊̀̈̅̎̿̂̂̍̐̕͝͠ͅF̵͕̼̪̰͚͚̠̼͎̺̘̲͐ ̴̧͕̜̞̝͉̠͔̜̏͂̔̃̋͆̋͐͑̀̐͊̈̈͌͘̚͠ͅI̷͙̝̱͈̩̪̿̂̀̃͒F̵̨̛̼͍̙̼͙̞͈̙̖́́͒̾̎̎́͐̔͌̒͜ ̵̧̡̢̛̮̞͈͈̳͉͈͙̠͕̜̗͎̆̀̓̈́͂̀̾͂̈́̑̂͂̈̽͐͘͘Ĩ̷̘̥̲̬̼͙̹̎̀̂̍̀͂̑́͐̽̃͒̂͂̋͝F̵̡̢̧͙̻̪̝̲̭̲̞̯͇̝̙̀̆̐͐͝ͅ IF IF IF', 'GIVE THEM THIS THIS Ì̶̡̡̛̛̩̜̜͎͖͔̳̗̟̲̞̻̯̑͐̿̊̑́͂̋̓̅͑̎̈́̾̈͑͐̔̽͆͘̚̕͘͜͝͝͠N̶̡̡̬̬̦̘͔̰͕̣̠͔͔̙̠̯̙̩̗̦͙͇͔͐̊̾͒̾̀̔͆̃̃̀̽͠͠ͅF̷̡̢͔͍̥͇̦̻̠̭̳̰͖̜̻̦͙̫̗̬̗͛̄̃̄͊̉͆̓̅̇̿̑̅̌̑̈͐̈́̊̈̽͝͠O̵̡̨̧̨̭̼͇̭̗̤̻͕̞͓͕̰͚̟̠̙͓̰͕̤͇̝͓̤͍̍͗͑́̀̉̇̐̊͐̎̈́̓̊̍̔̽͆̑͐̿̈́͌̌̃͂̅̔̃̚̚͠͝Ṙ̴̨̧̧͎̙̰͔͎̲͇͍̩̺̰̱̳̗̺̤̳̺̘͎̗̪̲͚͕̣͈̓̆̀̓͠͝͝M̷̢̧̨̦͉͓̖̥̗̱͈̜͔̼̫̟̰͖̬̯̗̳̻͈̥̭̞̹̥̲̻͋͂̒̔̓̌̾̿̌̇̅͆̽̑͛̎͐̉̃̈́̿̒̒̀̉͒͋̑͂͊̊͘̕͝͝͠͠Å̷̛̛̯̤̞̲͇̼̹̪͙̞͈͚̰̳͖̝͕͙̾̑̏̀̏̎͒̉̓̀̆̌́̈́̿̆̏͌̇́̆̕̚͝ͅT̸̨͖̠͚̬͇̖̤͙̓̾̋̍͌̎͘Ï̶̛͓̙̙̫͉̜̩͕͕̘͕̭̭̣͔̲̈́̈́̉̿̚̚ͅO̴̧̡͉̠̹̝̺̱̼̠͋̔͒̔̂̕͝N̷̨̧̛̛͖̩͚͈̘͕̝̹̹͚̦͈̼̼̻̫̱̥̦̩̬̥͚̠̙̖̲̖͊̓͊͆̑̋̑̍̀̄͐͐̇̈́̐̉͊̀̿͌̀̍̏̒̒̚͜͠ͅ ̶̢̧̢͍̻̹̮̪̱̜̞͔̟̩̥̣̲̞̠̼͇͎́̊̊̿̍͗̊̀́͑͂̏̍̐́͜͝͝ͅĮ̷̛̰̺̼̜͕̘̬̩̗̦̘͙̤͈̻͍̲̬̙̲̱̼̣̠͇̋͛͗̅̿̐͛̈͊̊͐͘̚͘͜͝Ń̵̰̤͕͈͓̣̰̺̥̼͎̆́́͒͑F̵̧̣̜̰̺̜͖͕͈̼̏͊Ơ̷̡̧̨͉͔͚̞̖̬͍̼̹̙̗͓̤̪̜̪̰͙͖͆̿̈͗̾͛̓̈́̍̐͗̈̒̄͛̽͋͊̍̕̕͜͝͝͝͝R̴̨̢̫͎̪̼͎͍̣̙̣͚͕͓̹̰͖͕̗̽́͛̅̏̃͗͑̽͛̃͆̆͂͗̚͘͝͠Ṃ̴̨̨̧̦̮̤̗̮̦̼͇̗̹̹͓̖͕̙̜͖̼̺̭̦̘̺̝̣͕̟̏̈́̈̓̇̐͜͜͝A̴̡̗͍̩̼̟̼̥͖͔̬̻̼̳͙͆̆͋̉̆̿͑͛̑̽͆T̴̘̗̗͉̰̰̱̗͗̃̒̃I̴̛̦͑̿̐̓̒͌̅͌̓̽͆̽̀̂́͆͐̽̊̽͒͋̓͑͘͘̚͠͝͠Ǫ̵̧̨̨̛̙̙͚̞̻͓͔̼̙̺̗̝̳̤͙̞̙̗͚̰͖̪̯̻̠͔̖͚͗̅́̽̌͊̉̃̈́̎̓̓͛͆̎̊͛͋̉̇̋̈̐̓̅̑͘͘̚̕͝͠͝͝͝N̷͚͔͓̼̉̌̀͛̈̀̿͑͐̎̑̎̃̄͠', 'IF IF IȊ̶̧̲̩̖̦͈̟͇̘̰̘̝̠̲̱̜̺͕̥͊̕F̵̢̛̦̝͍̠̪̩̾̒̽̈̉̋͂̂̓͛̎̉̏̕̚̕͝͠ ̸̧͉͉̲͖̟̤̜͚̙̺͓̤͇̻̎͗̃͊̐̿̃Į̸̨͖̜͕̥͎̞͈͖̱̞͖̱̮̤̘̲͍͙̞̑̈̂̍̎́̅̔͘̚͜͜͝͝ͅF̷̧̡̧̨̫͍̟̣͙̥̺̘͍͉̣͎̭̙̞̋̌̀̽̂̏͘ͅ ̸̡̯̳͍͈̣̹͎̰̪̤̠̫̦̼̮͔̰͕͍̰͙̝̆͛̃̀̓́̓̀̈́͒̒̓̌̈͑͑̇̋͌͆͝͠ͅĮ̵̢̧̨̨̱̩̭͕̦̲̫̺̯̩̦̖͓̖̘̰̰̥͗̅̀̿́̃̅̊̀͗̊̌̄̐͑̀̽̎͂̽̉͗͆̌͜͠͝F̵̨̨̧̤͎͖̹̹͉̠̼͖̝̗̦̘̥̬̭̹̝̞̱̠̀͐̀̀̒̆̎̃̽̌̌̈́͂̽͗̓͂̒͊̒̕̕͠͝͝ ̸̨̮̫͈̬̺̖̥͔̠̻̖̣̠͎̠̰͎͉͈̤̰̣̞͓̀̆̒̃͒͋̄͗̈́̏̽̈́̃̊̕̕͜͜͠͝͝͠ͅI̸̢̧̨̡͙͉͓͖͙̤͔̦̭̬̜͖͇̳͕͍͎͐̅̆̈́̈̑͊̈́̈́̋̂̿̈́́́̽͋͗̈͐̓̉̉̾̒̿̎̂̚͜͜͝ͅF̴̧̡̣͍̦̹̖̜̺̘̘̫̤̠̄̒͊̿̈̈́̑̃̎̏͛̑̓̍́̇̇̍̋́́̈́̎̃̒̕̚̕̕͝͠͠͝ IF IF']
const issue4 = ['Stop Code: >:)'];
const issue5 = [':D:D:D:D:D:D:D:D:D:D:D:D:D:D:D:D:D:D:D:D:D:D:D:D:D:D:D:D:D:D', 'For more information about this issue and possible fixes, visit'];


function unhacked() {
    IssueElement1.style.color = '#fefeff';
    IssueElement2.style.color = '#fefeff';
    IssueElement2.style.fontWeight = 'normal';
    IssueElement3.style.color = '#fefeff';
    IssueElement4.style.color = '#fefeff';
    IssueElement4.style.fontWeight = 'normal';
    IssueElement5.style.color = '#fefeff';
    IssueFace.style.color = '#fefeff'
    percentageElement.style.color = '#fefeff';
    percentageElement.style.fontWeight = 'normal';
    body.style.backgroundColor = '#3973aa';
    IssueElement1.innerText = "Your PC ran into a problem and needs to restart. We're just collecting some error info, and then we'll restart for you.";
    IssueElement2.innerText = "For more information about this issue and possible fixes, visit http://";
    IssueElement3.innerText = "xontab.com/stopcode";
    IssueElement4.innerText = "If you call a support person, give them this info:";
    IssueElement5.innerText = "Stop Code: 404 PAGE NOT FOUND";
    percentageElement.innerText = percentage;
    QRCODE.src = "http://xontab.com/experiments/Javascript/BSOD/qr.png";
    QRImage.style.backgroundColor = "white";
    body.style.backgroundImage = "";
    IssueFace.innerText = ':(';
    if (percentage >= 100) {
      percentage = 100;
    }
}

function hacked() {
    IssueElement1.style.color = 'red';
    IssueElement2.style.color = 'red';
    IssueElement2.style.fontWeight = 'bold';
    IssueElement3.style.color = 'red';
    IssueElement4.style.color = 'red';
    IssueElement4.style.fontWeight = 'bold';
    IssueElement5.style.color = 'red';
    percentageElement.style.color = 'red';
    percentageElement.style.fontWeight = 'bold';
    body.style.backgroundColor = 'black';
    IssueFace.style.color = 'red';
    IssueFace.style.fontWeight = "bold";
    var thing = things[Math.floor(Math.random()*things.length)];
    var Issuer1 = issue[Math.floor(Math.random()*issue.length)];
    var Issuer2 = issue2[Math.floor(Math.random()*issue2.length)];
    var Issuer3 = issue3[Math.floor(Math.random()*issue3.length)];
    var Issuer4 = issue4[Math.floor(Math.random()*issue4.length)];
    IssueFace.innerText = ':D';
    IssueElement1.innerText = Issuer1;
    IssueElement2.innerText = Issuer1;
    IssueElement3.innerText = Issuer2;
    IssueElement4.innerText = Issuer3;
    QRCODE.src = "Red_QR.png";
    QRImage.style.backgroundColor = "red";
    percentageElement.innerText = thing;
    if (percentage > 100) {
      percentage = 100;
    }
}

function hacked2() {
    IssueElement1.style.color = 'red';
    IssueElement2.style.color = 'red';
    IssueElement2.style.fontWeight = 'bold';
    IssueElement3.style.color = 'red';
    IssueElement4.style.color = 'red';
    IssueElement4.style.fontWeight = 'bold';
    IssueElement5.style.color = 'red';
    percentageElement.style.color = 'red';
    percentageElement.style.fontWeight = 'bold';
    IssueFace.style.color = 'red';
    IssueFace.style.fontWeight = "bold";
    var thing = things[Math.floor(Math.random()*things.length)];
    var Issuer1 = Issue[Math.floor(Math.random()*Issue.length)];
    var Issuer2 = Issue2[Math.floor(Math.random()*Issue2.length)];
    var Issuer3 = Issue3[Math.floor(Math.random()*Issue3.length)];
    var Issuer4 = issue4[Math.floor(Math.random()*issue4.length)];
    IssueFace.innerText = ':D';
    IssueElement1.innerText = Issuer1;
    IssueElement2.innerText = Issuer1;
    IssueElement3.innerText = Issuer2;
    IssueElement4.innerText = Issuer3;
    IssueElement5.innerText = Issuer4;
    body.style.backgroundImage = "url('hacked_background.gif')";
    QRCODE.src = "Red_QR.png";
    QRImage.style.backgroundColor = "red";
    percentageElement.innerText = thing;
    if (percentage >= 100) {
      percentage = 100;
    }
}

i = 0;
function process() {
  percentage += parseInt(Math.random() * 10);
  if (percentage >= 0 && percentage < 50 ) {
    percentageElement.innerText = percentage;
  }
  else if (percentage > 50 && percentage < 60 ) {
    hacked();
  }
  else if (percentage >= 60 && percentage <= 75 ) {
    unhacked();
  }
  else if (percentage > 75 && percentage < 100 ) {
    hacked2();
  }
  else if (percentage >= 100) {
    unhacked();
    IssueFace.innerText = ':)';
  }
  if (i > 5) {
    changeloc();
    }
    processInterval();
    if (percentage >= 100) {
      percentage = 100;
      i = i + 1;
      console.log(i);
    }
  }

function processInterval() {
  setTimeout(process, Math.random() * (1000 - 500) + 500);
}
processInterval();

