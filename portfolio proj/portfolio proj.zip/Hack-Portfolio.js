function hide() {
    document.getElementById('loading_screen');
}